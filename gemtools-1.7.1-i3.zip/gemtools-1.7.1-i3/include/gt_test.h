/*
 * PROJECT: GEM-Tools library
 * FILE: gt_test.h
 * DATE: 03/10/2012
 * AUTHOR(S): Santiago Marco-Sola <santiagomsola@gmail.com>
 * DESCRIPTION: // TODO
 */

#ifndef GT_TEST_H_
#define GT_TEST_H_

#include "check.h"
#include "gem_tools.h"

#endif /* GT_TEST_H_ */
